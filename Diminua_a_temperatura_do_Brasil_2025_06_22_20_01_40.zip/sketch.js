let brasilImg;

let arvores = [];

let tempo = 60;

let contador = 0;

let temperatura = 30;

let fim = false;

let sucesso = false;

function preload() {

  brasilImg = loadImage("Mapa.jpg");

}

function setup() {

  createCanvas(800, 600);

  setInterval(contarTempo, 1000);

  textFont('Arial');

}

function draw() {

  background(255);

  image(brasilImg, 100, 50, 600, 500);

  // Desenha as árvores

  for (let arv of arvores) {

    drawTree(arv.x, arv.y);

  }

  // HUD

  fill(0);

  textSize(20);

  text("Árvores plantadas: " + contador, 20, 30);

  text("Tempo restante: " + tempo + "s", 20, 60);

  text("Temperatura: " + temperatura + "°C", 20, 90);

  // Mensagem final

  if (fim) {

    textSize(28);

    fill(sucesso ? 'green' : 'red');

    let msg = sucesso

      ? "Você diminuiu a temperatura salvando o Brasil!"

      : "O Brasil superaqueceu!";

    text(msg, 100, height / 2);

  }

}

function mousePressed() {

  if (fim) return;

  // Posição aleatória dentro da área do mapa

  let x = random(100, 700);

  let y = random(50, 550);

  arvores.push({ x, y });

  contador++;

  // Diminui temperatura a cada 100 árvores

  if (contador % 100 === 0) {

    temperatura--;

  }

}

function contarTempo() {

  if (!fim) {

    tempo--;

    if (tempo <= 0) {

      fim = true;

      sucesso = (30 - temperatura) >= 5;

    }

  }

}

function drawTree(x, y) {

  fill(101, 67, 33); // tronco

  rect(x - 2, y, 4, 10);

  fill(34, 139, 34); // copa

  ellipse(x, y, 15, 15);

}